package it.unipd.bookly.utilities;

public class Util {
    public static String handleSpaceInURL(String url) {
        return url.replace("%20", " ");
    }
}
